<?php

require get_template_directory() . '/inc/setup.php';
require get_template_directory() . '/inc/sidebars.php';
require get_template_directory() . '/inc/enqueue.php';
