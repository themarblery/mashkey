<header class="post__header">
	<time><?php the_date(); ?></time>
	<h2 class="post__title"><?php the_title(); ?></h2>
</header>
