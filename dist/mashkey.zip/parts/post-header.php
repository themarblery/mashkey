<header class="post__header">
	<time><?php the_date(); ?></time>
	<h2 class="post__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
</header>
