<article id="post-<?php the_id(); ?>" <?php post_class(); ?>>
