<?php

get_template_part( 'parts/post-open' );

get_template_part( 'parts/post-header' );

get_template_part( 'parts/post-content' );

get_template_part( 'parts/post-close' );
